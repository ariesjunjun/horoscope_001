import ThreadClient from "./ThreadClient";

export default async function ThreadPage({
  params,
}: {
  params: { threadId: string };
}) {
  // Promiseを返すasync関数にすることで型整合性が取れる場合が多いです
  return <ThreadClient threadId={params.threadId} />;
}
