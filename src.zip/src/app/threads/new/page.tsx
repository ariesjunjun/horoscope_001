// app/threads/new/page.tsx
import NewThreadClient from "./NewThreadClient";

export default function NewThreadPage() {
  return <NewThreadClient />;
}
