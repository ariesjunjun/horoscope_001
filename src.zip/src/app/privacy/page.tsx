export default function PrivacyPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">プライバシーポリシー</h1>
      <p>ここにプライバシーポリシーの内容を書きます。</p>
    </div>
  );
}
