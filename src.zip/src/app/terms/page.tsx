"use client";

export default function termsPage() {
  return (
    <div>
      <h1>terms Page</h1>
    </div>
  );
}
