export type Tag = {
  id: string;
  name: string;
  count: number;
};
